Sam Jones
CS 362 Quiz 2
4/23/16

The inputChar() function generates a random number between 0-12 and then returns the character 
at the index of the random number generated in the character list.

The inputString() function generates a random 5 character string using r, e, s, t. 

The program took an average of 825,00 iterations before s = 'reset' and the error message is 
printed. 