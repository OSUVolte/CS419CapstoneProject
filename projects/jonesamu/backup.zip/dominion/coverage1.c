/*
Sam Jones
Date: 04/25/16

I have my unit tests and card tests is 53% statement coverage and
54% branch coverage.  The number of calls executed was 35%.  
I have an expectedly low coverage; I was not trying to test the entire program. 
I have 100% statement and branch coverage for the four unit tests 

The largest overal bug I discovered was; there is no input validation after
the game is initiliazed. No internal methods check ranges on inputs. If an invalid input was used
after the game was started the game would go on as normal and the player would have
no way of knowing.


*/